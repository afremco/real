// netlify/functions/verify-payment.js
//
// After the customer returns from the hosted checkout page,
// payment-callback.html calls this function with whatever reference the
// provider gave it. We NEVER trust the redirect alone (it can be spoofed)
// — we always re-verify server-side against the provider's API using our
// secret credentials before treating an order as paid.
//
// Set PAYMENT_PROVIDER to "flutterwave" (default) or "dpo" in Netlify's
// environment variables to match whichever one initiate-payment.js used.

exports.handler = async (event) => {
  const provider = (process.env.PAYMENT_PROVIDER || 'flutterwave').toLowerCase();
  const qs = event.queryStringParameters || {};

  if (provider === 'dpo') {
    return verifyDpo(qs);
  }
  return verifyFlutterwave(qs);
};

// ---------- Flutterwave ----------

async function verifyFlutterwave(qs) {
  const secretKey = process.env.FLUTTERWAVE_SECRET_KEY;
  if (!secretKey) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Server is not configured with a Flutterwave secret key.' }),
    };
  }

  const transactionId = qs.transaction_id;
  if (!transactionId) {
    return { statusCode: 400, body: JSON.stringify({ error: 'Missing transaction_id' }) };
  }

  try {
    const resp = await fetch(
      `https://api.flutterwave.com/v3/transactions/${encodeURIComponent(transactionId)}/verify`,
      { headers: { Authorization: `Bearer ${secretKey}` } }
    );
    const data = await resp.json();

    const txn = data && data.data;
    const isPaid = data.status === 'success' && txn && txn.status === 'successful';

    if (isPaid) {
      return {
        statusCode: 200,
        body: JSON.stringify({
          verified: true,
          amount: txn.amount,
          currency: txn.currency,
          txRef: txn.tx_ref,
          customer: txn.customer,
          paymentType: txn.payment_type,
        }),
      };
    }

    return { statusCode: 200, body: JSON.stringify({ verified: false, details: data }) };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
}

// ---------- DPO (Direct Pay Online) ----------

async function verifyDpo(qs) {
  const companyToken = process.env.DPO_COMPANY_TOKEN;
  if (!companyToken) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Server is not configured with a DPO company token.' }),
    };
  }

  const transactionToken = qs.transaction_token || qs.TransactionToken;
  if (!transactionToken) {
    return { statusCode: 400, body: JSON.stringify({ error: 'Missing transaction_token' }) };
  }

  const xml = `<?xml version="1.0" encoding="utf-8"?>
<API3G>
  <CompanyToken>${escapeXml(companyToken)}</CompanyToken>
  <Request>verifyToken</Request>
  <TransactionToken>${escapeXml(transactionToken)}</TransactionToken>
</API3G>`;

  try {
    const resp = await fetch('https://secure.3gdirectpay.com/API/v6/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/xml; charset=utf-8', Accept: 'application/xml' },
      body: xml,
    });
    const text = await resp.text();
    const result = extractTag(text, 'Result');
    const explanation = extractTag(text, 'ResultExplanation');

    // Result 000 = paid. See DPO's verifyToken response codes for the
    // full list (001 authorized, 900 not yet paid, 901 declined, etc.)
    if (result === '000') {
      return {
        statusCode: 200,
        body: JSON.stringify({
          verified: true,
          amount: extractTag(text, 'TransactionAmount'),
          currency: extractTag(text, 'TransactionCurrency'),
          txRef: transactionToken,
          customer: { name: extractTag(text, 'CustomerName') },
          paymentType: 'DPO',
        }),
      };
    }

    return { statusCode: 200, body: JSON.stringify({ verified: false, details: { result, explanation } }) };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
}

function escapeXml(str) {
  return String(str).replace(/[<>&'"]/g, (c) => (
    { '<': '&lt;', '>': '&gt;', '&': '&amp;', "'": '&apos;', '"': '&quot;' }[c]
  ));
}

function extractTag(xml, tag) {
  const m = xml.match(new RegExp(`<${tag}>([^<]*)</${tag}>`));
  return m ? m[1] : null;
}
