// netlify/functions/initiate-payment.js
//
// Starts a hosted checkout session with whichever payment provider is
// configured. Both providers redirect the customer to their own
// PCI-compliant page to enter card or mobile money (MTN/Airtel/Zamtel)
// details — we never touch raw card numbers or mobile money PINs.
//
// Set PAYMENT_PROVIDER to "flutterwave" (default) or "dpo" in Netlify's
// environment variables to choose which one is active.
//
// Flutterwave requires: FLUTTERWAVE_SECRET_KEY
// DPO requires: DPO_COMPANY_TOKEN (and optionally DPO_SERVICE_TYPE, a
//   numeric service type DPO assigns you during onboarding — if you don't
//   have one yet, a generic ServiceTypeName is sent instead)

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  let payload;
  try {
    payload = JSON.parse(event.body || '{}');
  } catch {
    return { statusCode: 400, body: JSON.stringify({ error: 'Invalid JSON body' }) };
  }

  const { amount, currency, customer, description } = payload;

  if (!amount || Number(amount) <= 0) {
    return { statusCode: 400, body: JSON.stringify({ error: 'A valid amount is required.' }) };
  }
  if (!currency) {
    return { statusCode: 400, body: JSON.stringify({ error: 'A currency is required.' }) };
  }
  if (!customer || !customer.email) {
    return { statusCode: 400, body: JSON.stringify({ error: 'Customer email is required.' }) };
  }

  const siteUrl = process.env.URL || `https://${event.headers.host}`;
  const provider = (process.env.PAYMENT_PROVIDER || 'flutterwave').toLowerCase();

  if (provider === 'dpo') {
    return initiateDpo({ amount, currency, customer, description, siteUrl });
  }
  return initiateFlutterwave({ amount, currency, customer, description, siteUrl });
};

// ---------- Flutterwave ----------

async function initiateFlutterwave({ amount, currency, customer, description, siteUrl }) {
  const secretKey = process.env.FLUTTERWAVE_SECRET_KEY;
  if (!secretKey) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Server is not configured with a Flutterwave secret key.' }),
    };
  }

  const txRef = `gadgethub-${Date.now()}-${Math.floor(Math.random() * 1e6)}`;

  const flutterwavePayload = {
    tx_ref: txRef,
    amount: Number(amount).toFixed(2),
    currency: currency,
    redirect_url: `${siteUrl}/payment-callback.html`,
    customer: {
      email: customer.email,
      phonenumber: customer.phone || '',
      name: customer.name || '',
    },
    customizations: {
      title: 'Gadget Hub',
      description: description || 'Order payment',
    },
    meta: { order_note: description || '' },
  };

  try {
    const resp = await fetch('https://api.flutterwave.com/v3/payments', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${secretKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(flutterwavePayload),
    });

    const data = await resp.json();

    if (data.status !== 'success' || !data.data || !data.data.link) {
      return {
        statusCode: 502,
        body: JSON.stringify({ error: 'Flutterwave could not start this payment.', details: data }),
      };
    }

    return { statusCode: 200, body: JSON.stringify({ link: data.data.link, tx_ref: txRef }) };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
}

// ---------- DPO (Direct Pay Online) ----------

async function initiateDpo({ amount, currency, customer, description, siteUrl }) {
  const companyToken = process.env.DPO_COMPANY_TOKEN;
  if (!companyToken) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Server is not configured with a DPO company token.' }),
    };
  }

  const companyRef = `gadgethub-${Date.now()}-${Math.floor(Math.random() * 1e6)}`;
  const nameParts = (customer.name || 'Customer').trim().split(/\s+/);
  const firstName = nameParts[0] || 'Customer';
  const lastName = nameParts.slice(1).join(' ') || 'N/A';

  const serviceType = process.env.DPO_SERVICE_TYPE;
  const serviceTag = serviceType
    ? `<ServiceType>${escapeXml(serviceType)}</ServiceType>`
    : `<ServiceTypeName>General</ServiceTypeName>`;

  const redirectUrl = `${siteUrl}/payment-callback.html`;

  const xml = `<?xml version="1.0" encoding="utf-8"?>
<API3G>
  <CompanyToken>${escapeXml(companyToken)}</CompanyToken>
  <Request>createToken</Request>
  <Transaction>
    <PaymentAmount>${Number(amount).toFixed(2)}</PaymentAmount>
    <PaymentCurrency>${escapeXml(currency)}</PaymentCurrency>
    <CompanyRef>${escapeXml(companyRef)}</CompanyRef>
    <RedirectURL>${escapeXml(redirectUrl)}</RedirectURL>
    <BackURL>${escapeXml(redirectUrl)}</BackURL>
    <CompanyRefUnique>0</CompanyRefUnique>
    <PTL>1</PTL>
    <customerFirstName>${escapeXml(firstName)}</customerFirstName>
    <customerLastName>${escapeXml(lastName)}</customerLastName>
    <customerEmail>${escapeXml(customer.email)}</customerEmail>
    <customerPhone>${escapeXml(customer.phone || '')}</customerPhone>
  </Transaction>
  <Services>
    <Service>
      ${serviceTag}
      <ServiceDescription>${escapeXml((description || 'Order payment').slice(0, 255))}</ServiceDescription>
      <ServiceDate>${dpoDateNow()}</ServiceDate>
    </Service>
  </Services>
</API3G>`;

  try {
    const resp = await fetch('https://secure.3gdirectpay.com/API/v6/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/xml; charset=utf-8', Accept: 'application/xml' },
      body: xml,
    });
    const text = await resp.text();
    const result = extractTag(text, 'Result');
    const transToken = extractTag(text, 'TransToken');
    const explanation = extractTag(text, 'ResultExplanation');

    if (result !== '000' || !transToken) {
      return {
        statusCode: 502,
        body: JSON.stringify({ error: explanation || 'DPO could not start this payment.' }),
      };
    }

    return {
      statusCode: 200,
      body: JSON.stringify({
        link: `https://secure.3gdirectpay.com/pay.asp?ID=${transToken}`,
        tx_ref: companyRef,
      }),
    };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
}

function dpoDateNow() {
  const d = new Date();
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}/${pad(d.getMonth() + 1)}/${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function escapeXml(str) {
  return String(str).replace(/[<>&'"]/g, (c) => (
    { '<': '&lt;', '>': '&gt;', '&': '&amp;', "'": '&apos;', '"': '&quot;' }[c]
  ));
}

function extractTag(xml, tag) {
  const m = xml.match(new RegExp(`<${tag}>([^<]*)</${tag}>`));
  return m ? m[1] : null;
}
